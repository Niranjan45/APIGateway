package com.example.APIGateway.Services;


import com.example.APIGateway.dto.ProductResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Slf4j
@Service
public class ProductService {

    public List<ProductResponse> getProducts() {
        log.info("ProductService - Fetching simulated products");
        return List.of(
                ProductResponse.builder()
                        .id(1L).name("Laptop Pro 15").category("Electronics")
                        .price(new BigDecimal("75000.00")).stock(25).status("IN_STOCK").build(),
                ProductResponse.builder()
                        .id(2L).name("Wireless Mouse").category("Accessories")
                        .price(new BigDecimal("1200.00")).stock(150).status("IN_STOCK").build(),
                ProductResponse.builder()
                        .id(3L).name("Mechanical Keyboard").category("Accessories")
                        .price(new BigDecimal("3500.00")).stock(0).status("OUT_OF_STOCK").build(),
                ProductResponse.builder()
                        .id(4L).name("4K Monitor").category("Electronics")
                        .price(new BigDecimal("32000.00")).stock(10).status("IN_STOCK").build(),
                ProductResponse.builder()
                        .id(5L).name("USB-C Hub").category("Accessories")
                        .price(new BigDecimal("2200.00")).stock(75).status("IN_STOCK").build()
        );
    }
}
