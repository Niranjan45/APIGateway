package com.example.APIGateway.SwaggerConfig;


import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.Components;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        final String apiKeyScheme = "X-API-KEY";
        return new OpenAPI()
                .info(new Info()
                        .title("API Gateway Simulation")
                        .description("Simulated API Gateway routing requests to internal services")
                        .version("1.0.0"))
                .addSecurityItem(new SecurityRequirement().addList(apiKeyScheme))
                .components(new Components()
                        .addSecuritySchemes(apiKeyScheme,
                                new SecurityScheme()
                                        .name(apiKeyScheme)
                                        .type(SecurityScheme.Type.APIKEY)
                                        .in(SecurityScheme.In.HEADER)));
    }
}
