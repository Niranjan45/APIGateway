package com.example.APIGateway.Services;



import com.example.APIGateway.dto.RequestLogResponse;
import com.example.APIGateway.model.RequestLog;
import com.example.APIGateway.Repository.RequestLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class RequestLogService {

    private final RequestLogRepository requestLogRepository;

    public void saveLog(String requestPath, String method,
                        Integer status, String clientIp, Long durationMs) {
        RequestLog requestLog = RequestLog.builder()
                .requestPath(requestPath)
                .method(method)
                .timestamp(LocalDateTime.now())
                .status(status)
                .clientIp(clientIp)
                .durationMs(durationMs)
                .build();
        requestLogRepository.save(requestLog);
        log.debug("Request log saved - Path: {}, Method: {}, Status: {}, Duration: {}ms",
                requestPath, method, status, durationMs);
    }

    public Page<RequestLogResponse> getAllLogs(Pageable pageable) {
        return requestLogRepository.findAll(pageable).map(this::toResponse);
    }

    public Page<RequestLogResponse> getLogsByPath(String path, Pageable pageable) {
        return requestLogRepository.findByRequestPath(path, pageable).map(this::toResponse);
    }

    public Page<RequestLogResponse> getLogsByMethod(String method, Pageable pageable) {
        return requestLogRepository.findByMethod(method, pageable).map(this::toResponse);
    }

    public Page<RequestLogResponse> getLogsByStatus(Integer status, Pageable pageable) {
        return requestLogRepository.findByStatus(status, pageable).map(this::toResponse);
    }

    private RequestLogResponse toResponse(RequestLog log) {
        return RequestLogResponse.builder()
                .id(log.getId())
                .requestPath(log.getRequestPath())
                .method(log.getMethod())
                .timestamp(log.getTimestamp())
                .status(log.getStatus())
                .clientIp(log.getClientIp())
                .durationMs(log.getDurationMs())
                .build();
    }
}
