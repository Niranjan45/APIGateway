package com.example.APIGateway.Repository;



import com.example.APIGateway.model.RequestLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface RequestLogRepository extends JpaRepository<RequestLog, Long> {
    Page<RequestLog> findByRequestPath(String requestPath, Pageable pageable);
    Page<RequestLog> findByMethod(String method, Pageable pageable);
    Page<RequestLog> findByStatus(Integer status, Pageable pageable);
    List<RequestLog> findByTimestampBetween(LocalDateTime from, LocalDateTime to);
}