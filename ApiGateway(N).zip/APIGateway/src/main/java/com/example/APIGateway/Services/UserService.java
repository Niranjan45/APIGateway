package com.example.APIGateway.Services;



import com.example.APIGateway.dto.UserResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class UserService {

    public List<UserResponse> getUsers() {
        log.info("UserService - Fetching simulated users");
        return List.of(
                UserResponse.builder()
                        .id(1L).name("Alice Johnson").email("alice@example.com")
                        .role("ADMIN").status("ACTIVE").build(),
                UserResponse.builder()
                        .id(2L).name("Bob Smith").email("bob@example.com")
                        .role("USER").status("ACTIVE").build(),
                UserResponse.builder()
                        .id(3L).name("Carol White").email("carol@example.com")
                        .role("MANAGER").status("INACTIVE").build(),
                UserResponse.builder()
                        .id(4L).name("David Brown").email("david@example.com")
                        .role("USER").status("ACTIVE").build(),
                UserResponse.builder()
                        .id(5L).name("Eva Green").email("eva@example.com")
                        .role("USER").status("ACTIVE").build()
        );
    }
}
