package com.example.APIGateway.dto;


import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OrderResponse {
    private Long id;
    private String orderNumber;
    private String customerName;
    private BigDecimal amount;
    private String status;
    private LocalDate orderDate;
}