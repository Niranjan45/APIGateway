package com.example.APIGateway.dto;



import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RequestLogResponse {
    private Long id;
    private String requestPath;
    private String method;
    private LocalDateTime timestamp;
    private Integer status;
    private String clientIp;
    private Long durationMs;
}
