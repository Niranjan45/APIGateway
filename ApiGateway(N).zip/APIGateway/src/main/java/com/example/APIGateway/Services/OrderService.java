package com.example.APIGateway.Services;


import com.example.APIGateway.dto.OrderResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
public class OrderService {

    public List<OrderResponse> getOrders() {
        log.info("OrderService - Fetching simulated orders");
        return List.of(
                OrderResponse.builder()
                        .id(1L).orderNumber("ORD-20240101").customerName("Niranjan K")
                        .amount(new BigDecimal("1500.00")).status("DELIVERED")
                        .orderDate(LocalDate.of(2024, 1, 1)).build(),
                OrderResponse.builder()
                        .id(2L).orderNumber("ORD-20240215").customerName("Bob Smith")
                        .amount(new BigDecimal("899.50")).status("SHIPPED")
                        .orderDate(LocalDate.of(2024, 2, 15)).build(),
                OrderResponse.builder()
                        .id(3L).orderNumber("ORD-20240310").customerName("Carol White")
                        .amount(new BigDecimal("2300.75")).status("PROCESSING")
                        .orderDate(LocalDate.of(2024, 3, 10)).build(),
                OrderResponse.builder()
                        .id(4L).orderNumber("ORD-20240401").customerName("David Brown")
                        .amount(new BigDecimal("450.00")).status("PENDING")
                        .orderDate(LocalDate.of(2024, 4, 1)).build(),
                OrderResponse.builder()
                        .id(5L).orderNumber("ORD-20240512").customerName("Eva Green")
                        .amount(new BigDecimal("3200.00")).status("DELIVERED")
                        .orderDate(LocalDate.of(2024, 5, 12)).build()
        );
    }
}