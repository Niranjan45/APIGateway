package com.example.APIGateway.Controllers;

import com.example.APIGateway.dto.*;
import com.example.APIGateway.Services.OrderService;
import com.example.APIGateway.Services.ProductService;
import com.example.APIGateway.Services.RequestLogService;
import com.example.APIGateway.Services.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api")

@Tag(name = "API Gateway", description = "Gateway endpoints routing to simulated internal services")
public class GatewayController {
@Autowired
    private  UserService userService;
@Autowired
    private  OrderService orderService;
@Autowired
    private  ProductService productService;
@Autowired
    private  RequestLogService requestLogService;

    @GetMapping("/users")
    @Operation(summary = "Get all users", description = "Routes to simulated User Service")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getUsers(
            @Parameter(hidden = true) HttpServletRequest request) {

        long start = System.currentTimeMillis();
        log.info("Gateway -> UserService | Method: {} | Path: {}", request.getMethod(), request.getRequestURI());

        List<UserResponse> users = userService.getUsers();
        long duration = System.currentTimeMillis() - start;

        requestLogService.saveLog(
                request.getRequestURI(),
                request.getMethod(),
                200,
                request.getRemoteAddr(),
                duration
        );

        log.info("Gateway <- UserService | Status: 200 | Duration: {}ms", duration);
        return ResponseEntity.ok(ApiResponse.ok("Users fetched successfully", users));
    }

    @GetMapping("/orders")
    @Operation(summary = "Get all orders", description = "Routes to simulated Order Service")
    public ResponseEntity<ApiResponse<List<OrderResponse>>> getOrders(
            @Parameter(hidden = true) HttpServletRequest request) {

        long start = System.currentTimeMillis();
        log.info("Gateway -> OrderService | Method: {} | Path: {}", request.getMethod(), request.getRequestURI());

        List<OrderResponse> orders = orderService.getOrders();
        long duration = System.currentTimeMillis() - start;

        requestLogService.saveLog(
                request.getRequestURI(),
                request.getMethod(),
                200,
                request.getRemoteAddr(),
                duration
        );

        log.info("Gateway <- OrderService | Status: 200 | Duration: {}ms", duration);
        return ResponseEntity.ok(ApiResponse.ok("Orders fetched successfully", orders));
    }

    @GetMapping("/products")
    @Operation(summary = "Get all products", description = "Routes to simulated Product Service")
    public ResponseEntity<ApiResponse<List<ProductResponse>>> getProducts(
            @Parameter(hidden = true) HttpServletRequest request) {

        long start = System.currentTimeMillis();
        log.info("Gateway -> ProductService | Method: {} | Path: {}", request.getMethod(), request.getRequestURI());

        List<ProductResponse> products = productService.getProducts();
        long duration = System.currentTimeMillis() - start;

        requestLogService.saveLog(
                request.getRequestURI(),
                request.getMethod(),
                200,
                request.getRemoteAddr(),
                duration
        );

        log.info("Gateway <- ProductService | Status: 200 | Duration: {}ms", duration);
        return ResponseEntity.ok(ApiResponse.ok("Products fetched successfully", products));
    }
}
