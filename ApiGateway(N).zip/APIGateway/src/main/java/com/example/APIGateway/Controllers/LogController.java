package com.example.APIGateway.Controllers;



import com.example.APIGateway.dto.ApiResponse;
import com.example.APIGateway.dto.RequestLogResponse;
import com.example.APIGateway.Services.RequestLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/logs")
@RequiredArgsConstructor
@Tag(name = "Request Logs", description = "APIs to view stored gateway request logs")
public class LogController {

    private final RequestLogService requestLogService;

    @GetMapping
    @Operation(summary = "Get all request logs with pagination")
    public ResponseEntity<ApiResponse<Page<RequestLogResponse>>> getAllLogs(Pageable pageable) {
        return ResponseEntity.ok(
                ApiResponse.ok("Logs fetched successfully", requestLogService.getAllLogs(pageable))
        );
    }

    @GetMapping("/path")
    @Operation(summary = "Filter logs by request path")
    public ResponseEntity<ApiResponse<Page<RequestLogResponse>>> getLogsByPath(
            @RequestParam String path, Pageable pageable) {
        return ResponseEntity.ok(
                ApiResponse.ok("Logs fetched by path", requestLogService.getLogsByPath(path, pageable))
        );
    }

    @GetMapping("/method")
    @Operation(summary = "Filter logs by HTTP method")
    public ResponseEntity<ApiResponse<Page<RequestLogResponse>>> getLogsByMethod(
            @RequestParam String method, Pageable pageable) {
        return ResponseEntity.ok(
                ApiResponse.ok("Logs fetched by method", requestLogService.getLogsByMethod(method, pageable))
        );
    }

    @GetMapping("/status")
    @Operation(summary = "Filter logs by response status code")
    public ResponseEntity<ApiResponse<Page<RequestLogResponse>>> getLogsByStatus(
            @RequestParam Integer status, Pageable pageable) {
        return ResponseEntity.ok(
                ApiResponse.ok("Logs fetched by status", requestLogService.getLogsByStatus(status, pageable))
        );
    }
}